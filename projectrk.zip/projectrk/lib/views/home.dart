import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:projectrk/views/splash.dart';


class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with TickerProviderStateMixin {

  FirebaseUser _user;
  final auth = FirebaseAuth.instance;
  final db = Firestore.instance;

  GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  GoogleMapController _controller;

  @override
  void initState() {
    super.initState();
    auth.currentUser().then((user){
      this._user = user;
    }).catchError((error){
      this._user = null;
    });
  }

  @override
  Widget build(BuildContext context) {

    Widget _normalAppBar(){
      return AppBar(
        backgroundColor: Color(0xFF3ACCE1),
        automaticallyImplyLeading: false,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(
            Icons.menu,
            color: Colors.white,
          ),
          onPressed: () { _scaffoldKey.currentState.openDrawer(); },
        ),
        title: Text(
          "Sitios",
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 16.0,
              color: Color(0xFFffffff)
          ),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              // Where the linear gradient begins and ends
              begin: FractionalOffset.topRight,
              end: FractionalOffset.bottomLeft,
              // Add one stop for each color. Stops should increase from 0 to 1
              stops: [0.0, 0.4, 1.0],
              colors: [
                new Color(0xFF3ACCE1),
                new Color(0xFF3ACCE1),
                new Color(0xFF3ACCE1)
              ],
              tileMode: TileMode.clamp,
            ),
          ),
        ),
      );
    }

    return WillPopScope(
      onWillPop: (){

      },
      child: Scaffold(
        key: _scaffoldKey,
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                child: Text('Drawer Header'),
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
              ),
              ListTile(
                leading: Icon(
                  Icons.power_settings_new,
                  color: Colors.black,
                ),
                title: Text('Cerrar Sesión'),
                onTap: () async {
                  await auth.signOut();
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Splash()),
                  );
                },
              ),
            ],
          ),
        ),
        resizeToAvoidBottomInset: false,
        appBar: _normalAppBar(),
        body: Stack(
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                color: Colors.redAccent
              ),
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(40.7128, -74.0060),
                  zoom: 12.0,
                ),
                onMapCreated: _mapCreated,
              ),
            ),
          ],
        )
      ),
    );
  }

  void _mapCreated(controller) {
    setState(() {
      this._controller = controller;
    });
  }
}