
class Coordinates {

  String _lat;
  String _lng;

  Coordinates();


  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();

    map["lat"] = this._lat;
    map["lng"] = this._lng;

    return map;
  }

  Coordinates.fromMap(Map<String, dynamic> map) {

    this._lat = map["lat"];
    this._lng = map["lng"];

  }

  String get lng => _lng;

  set lng(String value) {
    _lng = value;
  }

  String get lat => _lat;

  set lat(String value) {
    _lat = value;
  }


}